-- Menu Name Created by Author
set_menu_name = "Trivia"

-- Bot Name


set_bot_name = " Trivia "
function VH_OnUserLogin(nick)


if GetClass(nick) >= 0 then

	VH:SendDataToUser ("$UserCommand 1 3  "..set_menu_name.."$#124;|", nick)
	VH:SendDataToUser ("$UserCommand 1 3  $#124;|", nick)
	VH:SendDataToUser ("<"..set_bot_name..">    |", nick)
	VH:SendDataToUser ("$UserCommand 0 3|", nick)
end

if GetClass(nick) >= 3 then


------
	
end



if GetClass(nick) >=5 then
        
----
       	
end


if GetClass(nick) >= 10 then

---
			
end

if GetClass(nick) >= 0 then

	VH:SendDataToUser ("$UserCommand 1 3 Trivia\\top\\- top 10 - $<%[mynick]> -top&#124;|", nick)
	VH:SendDataToUser ("$UserCommand 0 3|", nick)
	VH:SendDataToUser ("$UserCommand 1 3 Trivia\\top\\- eternal top - $<%[mynick]> -tope&#124;|", nick)
	VH:SendDataToUser ("$UserCommand 0 3|", nick)
	VH:SendDataToUser ("$UserCommand 1 3 Trivia\\top\\- hour's top - $<%[mynick]> -tophour&#124;|", nick)
	VH:SendDataToUser ("$UserCommand 0 3|", nick)
	VH:SendDataToUser ("$UserCommand 1 3 Trivia\\top\\- day's top - $<%[mynick]> -topday&#124;|", nick)
	VH:SendDataToUser ("$UserCommand 0 3|", nick)
	VH:SendDataToUser ("$UserCommand 1 3 Trivia\\top\\- week's top - $<%[mynick]> -topweek&#124;|", nick)
	VH:SendDataToUser ("$UserCommand 0 3|", nick)
	VH:SendDataToUser ("$UserCommand 1 3 Trivia\\top\\- toprun - $<%[mynick]> -toprun&#124;|", nick)
	VH:SendDataToUser ("$UserCommand 0 3|", nick)
	VH:SendDataToUser ("$UserCommand 1 3 Trivia\\top\\- eternal toprun - $<%[mynick]> -toperun&#124;|", nick)
	VH:SendDataToUser ("$UserCommand 0 3|", nick)
	VH:SendDataToUser ("$UserCommand 1 3 Trivia\\top\\- hour's toprun - $<%[mynick]> -tophourrun&#124;|", nick)
	VH:SendDataToUser ("$UserCommand 0 3|", nick)
	VH:SendDataToUser ("$UserCommand 1 3 Trivia\\top\\- day's toprun- $<%[mynick]> -topdayrun&#124;|", nick)
	VH:SendDataToUser ("$UserCommand 0 3|", nick)
	VH:SendDataToUser ("$UserCommand 1 3 Trivia\\top\\- week's toprun - $<%[mynick]> -topweekrun&#124;|", nick)
	VH:SendDataToUser ("$UserCommand 0 3|", nick)
	VH:SendDataToUser ("$UserCommand 1 3 Trivia\\top\\- Average top speed - $<%[mynick]> -topv&#124;|", nick)
	VH:SendDataToUser ("$UserCommand 0 3|", nick)
	VH:SendDataToUser ("$UserCommand 1 3 Trivia\\top\\- Instant top speed - $<%[mynick]> -topvi&#124;|", nick)
	VH:SendDataToUser ("$UserCommand 0 3|", nick)
	VH:SendDataToUser ("$UserCommand 1 3 Trivia\\top\\- Instant top  eternal speed - $<%[mynick]> -topevi&#124;|", nick)
	VH:SendDataToUser ("$UserCommand 0 3|", nick)
	VH:SendDataToUser ("$UserCommand 1 3 Trivia\\top\\- top fastest response - $<%[mynick]> -topvr&#124;|", nick)
	VH:SendDataToUser ("$UserCommand 0 3|", nick)
	VH:SendDataToUser ("$UserCommand 1 3 Trivia\\top\\- top eternal fastest response - $<%[mynick]> -topevr&#124;|", nick)
	VH:SendDataToUser ("$UserCommand 0 3|", nick)
	VH:SendDataToUser ("$UserCommand 1 3 Trivia\\top\\- top records - $<%[mynick]> -toprec&#124;|", nick)
	VH:SendDataToUser ("$UserCommand 0 3|", nick)
	VH:SendDataToUser ("$UserCommand 1 3 Trivia\\top\\- top awards - $<%[mynick]> -topp&#124;|", nick)
	VH:SendDataToUser ("$UserCommand 0 3|", nick)
	VH:SendDataToUser ("$UserCommand 1 3 Trivia\\duel\\- challenge to a duel - $<%[mynick]> -duel&#124;|", nick)
	VH:SendDataToUser ("$UserCommand 0 3|", nick)
	VH:SendDataToUser ("$UserCommand 1 3 Trivia\\duel\\- accept the challenge to a duel - $<%[mynick]> -aduel&#124;|", nick)
	VH:SendDataToUser ("$UserCommand 0 3|", nick)
	VH:SendDataToUser ("$UserCommand 1 3 Trivia\\duel\\- challenge the double duel with ...- $<%[mynick]> -dduel%[nick] %[line:coleg duel]&#124;|", nick)
	VH:SendDataToUser ("$UserCommand 0 3|", nick)
	VH:SendDataToUser ("$UserCommand 1 3 Trivia\\duel\\- accept the double duel with - $<%[mynick]> -adduel&#124;|", nick)
	VH:SendDataToUser ("$UserCommand 0 3|", nick)
	VH:SendDataToUser ("$UserCommand 1 3 Trivia\\duel\\- challenge to a duel on .....with a stake of  ....$<%[mynick]> -duelt%[nick] %[line: provoci pe....- ...cu o miza]&#124;|", nick)
	VH:SendDataToUser ("$UserCommand 0 3|", nick)	
	VH:SendDataToUser ("$UserCommand 1 3 Trivia\\duel\\- challenge to a duel on .....with a stake of  .... offering an advantage of 5 questions- $<%[mynick]> -duelta%[nick] %[line:provoci pe ....- cu o miza de....(sub 500)]&#124;|", nick)
	VH:SendDataToUser ("$UserCommand 0 3|", nick)
	VH:SendDataToUser ("$UserCommand 1 3 Trivia\\duel\\ - My duels $<%[mynick]> -myduel&#124;|", nick)
	VH:SendDataToUser ("$UserCommand 0 3|", nick)
	VH:SendDataToUser ("$UserCommand 1 3 Trivia\\Other\\ - About Me $<%[mynick]> -si&#124;|", nick)
	VH:SendDataToUser ("$UserCommand 0 3|", nick)
	VH:SendDataToUser ("$UserCommand 1 3 Trivia\\Other\\- Information on... $<%[mynick]> -sip %[nick] %[line:nickname]&#124;|", nick)
	VH:SendDataToUser ("$UserCommand 0 3|", nick)



end

if GetClass(nick) > 0 then

 ---
end
	return 0
end

function GetClass(nick)
       res, class = VH:GetUserClass(nick)
       if res and class then
                return class
       else
                return false
       end
end
