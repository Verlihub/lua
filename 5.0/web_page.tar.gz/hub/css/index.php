<?php
header("HTTP/1.1 302 Moved Temporarily");
header("Location: ../");
?>