// iFrame Script resizing
function ChangeToNews()
{
	document.getElementById("myIframe").width="95%"
	document.getElementById("myIframe").height="75%"
	document.getElementById("myIframe").src="news.php"
	document.getElementById("myIframe").scrolling="auto"
}
function ChangeToSearch()
{
	document.getElementById("myIframe").width="99%"
	document.getElementById("myIframe").height="75%"
	document.getElementById("myIframe").src="hubsearch/index.php"
	document.getElementById("myIframe").scrolling="auto"
}
function ChangeToChat()
{
	document.getElementById("myIframe").width="85%"
	document.getElementById("myIframe").height="75%"
	document.getElementById("myIframe").src="chat.html"
}
function ChangeToUsers()
{
	document.getElementById("myIframe").width="auto"
	document.getElementById("myIframe").height="75%"
	document.getElementById("myIframe").src="users.php"
	document.getElementById("myIframe").scrolling="auto"
}
function breakout()
{
if (window.top!=window.self) 
  {
  window.top.location="news.php";
  }
}