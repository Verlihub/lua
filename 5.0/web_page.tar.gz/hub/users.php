<head>
    <title>..:: VerliHub | Online Users ::..</title>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>
<html>
    <body>
<!Css style>
<link href="css/s.css" rel="stylesheet"><body class="u">

<?php
require('./config.php');
mysql_connect(Db_host,Db_user,Db_pass);
mysql_select_db(Db_name);

// How many Users Online
$result = mysql_query("SELECT * FROM users_list") or die("Query failed : " . mysql_error());;
$num_rows = mysql_num_rows($result);
echo "Online Users: $num_rows";
?>

<!Css style for Nick List>
<p class="u">
<?php
// Select all nick from table "users_list"
$Nick = mysql_query("SELECT * FROM users_list");

// Write nick List from table
while ($NickList = mysql_fetch_array($Nick) )
{
echo $NickList['nick'];
echo "<br/>\n";
}

// Close Mysql connection
mysql_close();
?>

    </body>
</html>