<head>
    <title>..:: VerliHub | Last News ::..</title>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<script src="css/java/js.js"></script>
</head>
<html>
    <body>
<link href="css/s.css" rel="stylesheet"><body class="n">
<?php
function analyse_text($str) {
// find links http, ftp, mail.
  $str = eregi_replace ('(((f|ht){1}tp://)[-a-zA-Z0-9@:%_+.~#?&//=]+)', '
<a href="\1" target="_blank">\1</a>', $str);
  $str = eregi_replace('([[:space:] ()[{}])(www.[-a-zA-Z0-9@:%_+.~#?&//=]+)', '\1
<a class="ulink" href="http://\2" target="_blank">\2</a>', $str);
  $str = eregi_replace ('([_.0-9a-z-]+@([0-9a-z][0-9a-z-]+.)+[a-z]{2,3})', '
<a class="ulink" href="mailto:\1">\1</a>', $str);
// find Smiley
  $str = eregi_replace (':))', '<img src="img/amirose_2.bmp">', $str);
  $str = eregi_replace (':)', '<img src="img/amirose_0.bmp">', $str);
  $str = eregi_replace ('lol', '<img src="img/lol.gif">', $str);
  $str = eregi_replace (':D', '<img src="img/amirose_32.bmp">', $str);
  $str = eregi_replace (':p', '<img src="img/amirose_31.bmp">', $str);
  $str = eregi_replace ('8-)', '<img src="img/amirose_6.bmp">', $str);
  $str = eregi_replace ('wow', '<img src="img/amirose_7.bmp">', $str);
  $str = eregi_replace (':-]', '<img src="img/amirose_40.bmp">', $str);
  $str = eregi_replace (':-)', '<img src="img/amirose_3.bmp">', $str);
  $str = eregi_replace ('joint', '<img src="img/smoke.gif">', $str);
  return $str;
}
?>

<?php
// Connection to Mysql
require('./config.php');
mysql_connect(Db_host,Db_user,Db_pass);
mysql_select_db(Db_name);
?>
<form name="liste" title="Show specified type">
<select size=1 name="choix" title="">
<option value=news.php></option>

<?php
$types_req = mysql_query("SELECT * FROM files_type") or die("Query failed : " . mysql_error());;
// Write types Drop List
while ($parse_types = mysql_fetch_array($types_req) )
{
?>
<option value=news.php?id=<?php echo $parse_types['id'];?>>(<?php echo $parse_types['count'];?>)&nbsp;<?php echo $parse_types['type'];?></option>
<?php
}
?>
<td class="b1 header bg_light" nowrap><input onclick=window.location.href=document.liste.choix.options[document.liste.choix.selectedIndex].value type=button value="Ok" title="Validate" name=bouton>&nbsp;<input type="button" onclick="breakout()" value="Break out!" title="Break out this window">
</td>
</select>
</form>
<?php
$type_id = $_GET['id'];

IF ($type_id != "")
// SQl query
$news_req = mysql_query("SELECT * FROM files_list WHERE type='$type_id' ORDER BY id DESC") or die("Query failed : " . mysql_error());;

IF ($type_id == "")
// SQl query
$news_req = mysql_query("SELECT * FROM files_list ORDER BY id DESC") or die("Query failed : " . mysql_error());;

// Write news
while ($parse_news = mysql_fetch_array($news_req) )
{
?>
<table class="n" width="100%">
  <tr>
    <td>#<?php echo $parse_news['id'];?> { <?php echo $parse_news['title'];?> }</td>
    <td align=right><?php echo $parse_news['date'];?></td>
  </tr>
</table>
<p class="n">
Poster: <?php echo $parse_news['adder'];?>
<br/>
File: <?php echo $parse_news['file'];?>
<br/>
Path: <?php echo $parse_news['path'];?>
<br/>
Comment: <?php echo analyse_text($parse_news['comment']);?>
</p><br/>
<?php
}
// Close MySql connection
mysql_close();
?>

</body>
</html>