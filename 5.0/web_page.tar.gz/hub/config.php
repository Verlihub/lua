<?php
// MySQL Database Configuration, see DBCONFIG file in your VERLIHUB FOLDER
define("Db_host","localhost");
define("Db_user","your_verlihub_user_here"); // your Verlihub DATABASE USER
define("Db_pass","your_pass_here"); // your Verlihub DATABASE PASSWORD
define("Db_name","your_database_name_here"); // your Verlihub DATABASE NAME
?>