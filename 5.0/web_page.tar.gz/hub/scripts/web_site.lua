                           -- CHat History WebPage for VerliHub (lua 5.1) --
					-- By Kurupt --


------------- S c r i p t     S e t t i n g s -------------

-- Bot for PM  &  H e l p 
Bot ="[WeB]master";

-- Path to Chat history page, file must be created with write permission for the user running hub.
ChatFile = "/var/www/htdocs/hub/chat.html";

-- The link to your Web Site/hub/
WebSite = "http://your_web_site/hub/";

-- Number of Chat message in history
NbrHisto = 30;

-- Update the Chat page if you don't want to wait for auto update.
UCom = "!iframe";

-- Clear the history chat & web page
ClearCom = "!whisto";

-- Time in secondes for updating Chat Page (300 = 5mn)
maxTicks = 300;
-----------------------------------------------------------

-- Table for Chat message
Web = {}
-- some html code
inf ="&#060;"; -- html <
sup ="&#062;"; -- html >
-- do not change.
TimerTicks = 0

function Main()
	HubSecurity = GetHubSecurity()
end

-- Write Chat History page On Specified Timer
enableTimer = 1;

function VH_OnTimer()

	if (enableTimer == 0) then return 1 end

	TimerTicks = TimerTicks + 1
		if (TimerTicks == maxTicks) then
		SaveChat()
		TimerTicks = 0
		end
end

-- Memorize Chat messages in a lua table
function VH_OnParsedMsgChat(nick, Chat)
	
	local s, e, pre = string.find(Chat, "^%b<> (.)")
	table.insert(Web, os.date(" [%H:%M] "..inf..nick..sup.." ")..string.sub(Chat, 1, -1))
	
		if table.getn(Web) > NbrHisto then
		table.remove(Web, 1)
		end
	return 1
end

-- Write html page
function SaveChat()
	local File = io.open(ChatFile , "w")
	
	if File then
		local n = table.getn(Web)
		-- Write font style
		File:write("\<link href=\"css/s.css\" rel=\"stylesheet\"\>\<body class=\"c\"\>", "\n")
		-- write header with number of message in history
		File:write("Chat History Last: [ "..n.." ] message(s)\<br\>\<br\>\<p class=\"c\"\>", "\n");
		-- Write MainChat History
		for i = 1, n do
			File:write(Web[i].."\<br\>", "\n")
		end
		File:close()
	end
end

-- Operator command to update page & H e l p 
function VH_OnOperatorCommand(nick, Com)
	
	-- Command to update Hub page
	if (string.find(Com, UCom, 1, 1)) then
		SaveChat()
		VH:SendDataToUser("<"..Bot.."> Web page updated: "..WebSite.."", nick)
	return 0

	elseif (string.find(Com, ClearCom, 1, 1)) then
 		Web = {}
		SaveChat()
		VH:SendDataToAll("<"..Bot.."> ** W e b   C h a t   H i s t o r y    C l e a r e d **|",3, 10)
	return 0

	-- help
	elseif (string.find(Com, "!help", 1, 1)) then
		Tab = "\t\t\t"
		-- H e l p  message
		VH:SendDataToUser("$To: "..nick.." From: "..HubSecurity.." $<"..Bot
		..">\n\n"..Tab..UCom..Tab.."\tUpdate Web Chat Page.\n"..Tab
		..ClearCom..Tab.."\tClear & Update Web Chat Page.\n"..Tab
		.."History"..Tab.."\t[ "..NbrHisto.." ] messages in history\r\n"..Tab
		.."Web Page"..Tab..WebSite.."\r\n", nick)
	end
	return 1
end

-- SQL-fetch short-hand function.
function SF(row)
	return VH:SQLFetch(row);
end;

-- Get The Hub Security Name
function GetHubSecurity()
	res, val = VH:GetConfig("config", "hub_security")
	return val
end;
-- End
