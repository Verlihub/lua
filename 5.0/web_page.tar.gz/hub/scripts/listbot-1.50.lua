--|                                                      |--
--| ListBot v 1.50                                       |--
--| Written by Hellkeepa, hellkeeper_1@hotmail.com       |--
--| CopyLeft, but please let me know if you change       |--
--| anything. Always remember to credit original author: |--
--| No-one appreciates having their work stolen. ;-)     |--
--|                                                      |--
--| A thousand thanks to the following people for        |--
--| helping me with development and testing:             |--
--|    EmOuBi (feature requests & bug-testing)           |--
--|    Frog-sama (bug-testing & -fixing)                 |--
--|    kme (feature requests & bug-testing)              |--
--|    Dr.Lee (feat. req, de-bugging and some coding)    |--
--|    ZeroSleep (feat. req, bug-testing & -fixing)      |--
--|    Hurbold (bug-testing & -fixing)                   |--
--|                                                      |--

--[[ New features?
-- +rlsfind string --> To search for a release
-- Sub-types.
-- Comment/review handling & table.
-- Change detail command, "!cdata <field> <new val>"
]]--

if true then -- To hide the bloody changelog.
--[[ Changelog:
-- 1.50	Date and time for News, added
-- 1.40	Added support for web-based frontend, added
		variable to set how many news to list, and
		added a simple "user's top-10" system. Also
		fixed the right-click menu a bit, and some
		minor tweaks overall in the script.

-- 1.32	Changed the layout of the remaining "!list"
		options for files, thanks to Dr.Lee again. :-)

-- 1.31	Fixed blocking of PMs, and cleaned up the code
		of the PM event handler a bit.

-- 1.30	Removed newline from start-up message, fixed the
		"Warning" message popping up on all PM-commands,
		moved the "!ctype" help into admin-only part, and
		fixed item-counting when using "!ctype".
		New feature: Right-click menu, thanks to Dr.Lee!
		Also added toggable news PM to connecting users,
		and command to configure the alerts & menu.

-- 1.24	Changed sorting for "!list new" to "ASC" &
		added a missing space in the SQL query, added
		a "+" to the bot's description, cleaned up help
		message a bit, added custom messages on "!list *"
		when no results found, slight change to the
		layout of the "!list new" report, fixed bug with
		using "string" type file type in "!fadd", same
		problem with "!fdel" which is fixed as well, and
		fixed bug with wrong variable being used in "!dtype".
		Lastly I removed bogus "failed" message in "!ctype",
		and added a "unknown command" for PMs.

-- 1.23	Fixed bug in SQL-query for "!fdel", moved "!ctype"
		to admin commands, fixed missing "s" in table
		name for "!list new", and corrected error-
		message in "!fdel" to say "ID" instead of "Type".
		Also made it sort types on "!list types", and
		added some beautification code to paths.

-- 1.22	Changed layout of "!list new" report, thanks
		to Dr.Dre for making it for me :-), changed
		the "type" in listing from id to text
		and added a fail-safe check at the same time.
		Also added "!ctype" command, to change the
		type of a file.
		Changed "id" in "!fdel" file-deletion query
		to "type", and fixed wrong placement of the
		starting paranthesis in "Check_Commands()"
		for "!list range".

-- 1.21	Fixed a bug with unset "tid" in "!fdel",
		added a check for unset "tt" in "!list all",
		and added a confirmation message to "!fadd".
		Also fixed a bug in the syntax of some calls
		to "MsgOps()", and added an error-catching
		routine for "!fdel".
		Last, but not least, I added missing help-message
		for "!list range", and finally made the script
		delete all files of type in "!dtype".

-- 1.20	Added "list all" & "range <min> <max>" functions,
		and fixed access-check in the help message to
		use the "set_cls_admin" variable when checking
		for access to admin commands. Also added
		support for commands to the Bot via PM, and
		some minor tweaks to the event handler code:
		Removed some unused and unneccesary variables,
		and shelled out command parsing/execution to
		a function of it's own: "Check_Commands()"

-- 1.11	Fixed typo in one SQL query, from "addr" to
		"adder". Also fixed DB update script a bit.

-- 1.10	Added item count for types, "added by" field
		for files list, and support for string in
		"type" field when adding files.

-- 1.02	Fixed problem with "ttype" var being "nil".

-- 1.01	Fixed problem with bot e-mail variable,
		fixed wrong index used in "ParseData()",
		added escaping of slashes for "!fadd",
		and added better formatting for lists.

-- 1.00	Cleaned up code, and released it as "stable".

-- 0.96	Reverted optimalization changes in "ParseData()".

-- 0.95	Fixed "AddFile()" RegExp to support "+fadd", and added
		test to check if data has been submitted correctly.
		Also fixed test in "StrFix()" to check for "nil".

-- 0.94	Added support for +set_cmd_help, replaced RegExps
		for "!fadd" with custom function, and added reporting
		PMs to add and delete commands w/on-off variable.
		Added support for "+" to all commands, and fixed
		"IsClass()" to return true on class as well.
		ALso added two new control variables, to customize
		who gets access to the bot.

-- 0.93	Added missing "then" in "Main()", and added
		support for "+" commands for general users.
		Also changed help-message to have variable
		prefix, "!" for OPs or "+" for users.

-- 0.92	Added a missing underscore (_) at line 647,
		added a missing newline to the help-message,
		and added a missing "res, " at line 542.
		Also added the "use_existing_bot" variable,
		re-arranged the order of ID and type in "!list types",
		and rewrote the test for legal chars in the
		"StrFix()" function.

-- 0.91	Removed debugging code, and fixed the if()
		statement for the determination of file-type
		passed. Also cleaned up the "FixStr()" RegExps.

-- 0.90	Added parsing of user-called help command,
		added check for ID-number check on file-adding,
		and minor RegExp re-write for "!fadd" and "!list".

-- 0.85	Added checks for NULL-fields from database
		in "ListNew()" and "ListFiles()" functions,
		also added type-casting to number for ID-checks
		in "AddFile()".

-- 0.84	Fixed a few errors with variable names, and
		renamed "VH:SQLFetchRow()" to the correct
		"VH:SQLFetch()". Changed RegExp in "!fadd",
		removed double-slashes. And finally added
		a forgotten instance of "SF()".

-- 0.83	Fixed a few SQL errors, added a few checks
		for correct values, and a couple of typos.
		Thanks to Dr.Lee for pointing these out. :-)

-- 0.82	Fixed several syntax errors and typos, added
 		better handling of some errors, and changed to
		correct database handling (uses FetchRow now to
		actually retrieve the data) for all queries.

-- 0.81	Added file-type check for "!list" command, and
		rewrote the RegExp for "!fadd" to take the 3 neccesary
		parametres only.

-- 0.8	Added double-escaping to "denylist" variable, and
		removed a forgotten block of code.

-- 0.71	Fixed broken newline, which left string open.

-- 0.7	Added new functions: DelFile(), DelType() & ListNew().
		Updated help message.
		Changed ListFiles() to work with both ID and name of type.
		Added possibility for use of quotes in !fadd.
		Shortened down some very long lines.
		Changed the class of the bot to 10.
		Fixed SQL for creating "files_type" table.
]]--
end;

if true then -- To hide the global variables.
-- Give users of this class, and above, rights to add and delete files & types.
set_cls_admin = 4;

-- Give users of this class, and above, rights to view files and types.
set_cls_user = 0; -- Controls the use of "set_cls_top" commands as well.

-- Give users of this class, and above, rights to have their own Top-10 lists.
set_cls_top = 1; -- Recommended to be at least 1 to protect the lists.

-- Command for user-help, change it if you want to.
set_cmd_help = "help_files";

-- Use existing bot? "true" is yes, and "false" is no.
use_existing_bot = true;

-- The name for the bot, set to existing bot if above is "true".
set_bot_name = "ListBot"

-- Set the title to be used for the menu-entry.
set_bot_menu = ".:: ListBot"

-- Replace with your e-mail address.
set_bot_email = "hellkeeper_1 (at) hotmail (dot) com";

-- Change this too, if you want; Bot-description.
set_bot_desc = "Write +"..set_cmd_help.." in main for commands.";

-- Name for table. Can be changed, but no need.
set_db_table = "files_list";

-- Table for file-types: "Game", "Music", etc. (Same as above)
set_db_types = "files_type";

-- Table for Top-10 lists, same as for "set_db_table".
set_db_top = "files_top";

-- Domain & base-path for web-hosting.
set_wh_path = "aaremma.pointclark.net/vh"

-- Controls how many files to list in the "news" section.
set_no_news = 10;

-- Determine wether or not URL (web-path) should be used in lists.
set_wh_use = false;

-- Determine wether or not all admins should be alerted on add/del.
set_op_alert = false;

-- Set this to "true" to PM the "10 newest files" to connecting users, "false" disables.
set_us_news = false;

-- Set this to "true" to send the right-click menu to connecting users, "false" disables.
set_us_menu = true;

-- Set this to "true" to enable the use of personal Top-10 lists.
set_use_top10 = true;

-- No need to change this
set_str_lim = "-----------------------------------------------------------------------";


--|                                                      |--
--| Please do not edit anything below, unless you        |--
--| _know_ what you're doing: Very good chance of        |--
--| rendering the script unusable otherwise.             |--
--|                                                      |--
end;

-- Main function, is executed when starting HUB / loading script.
function Main()
	-- Define local variables, for later use.
	local db_field, res, err, count;

	-- Check if script should add a new bot.
	if (not use_existing_bot or use_existing_bot == 0) then
		-- Add new bot.
		VH:AddRobot(set_bot_name, 10, set_bot_desc, "Bot ", set_bot_email, "0");
	else
		set_bot_name = Get_Config("hub_security");
	end;

	-- Create table if it doesn't exist.
	db_fields = " (id MEDIUMINT(8) UNSIGNED NOT NULL AUTO_INCREMENT, type TINYINT(1) NOT NULL, "..
		"title VARCHAR(100) NOT NULL, file VARCHAR(255) NOT NULL, path VARCHAR(255), "..
		"comment VARCHAR(255), adder VARCHAR(60) NOT NULL DEFAULT \"N/A\", date VARCHAR(35), PRIMARY KEY (id))";
	sql = "CREATE TABLE IF NOT EXISTS "..set_db_table..db_fields;
	res, err = SQ(sql);

	-- Check if creation was successful.
	if (not res) then
		-- Table creation failed, send error message.
		MsgMain("\n*** Error!\n*** Could not create table: "..set_db_table..".", 5, 10);
		MsgMain("*** Error message was: "..err.."\n*** SQL statement: "..sql.."\n", 5, 10);
		return false;
	end;

	-- Create types table.
	db_fields = " (id TINYINT(1) NOT NULL AUTO_INCREMENT, type varchar (30) NOT NULL, count int(4) NOT NULL, PRIMARY KEY (id))";
	sql = "CREATE TABLE IF NOT EXISTS "..set_db_types..db_fields;
	res, err = SQ(sql);

	-- Check if creation was successful.
	if (not res) then
		-- Table creation failed, send error message.
		MsgMain("\n*** Error!\n*** Could not create table: "..set_db_types..".", 5, 10);
		MsgMain("*** Error message was: "..err.."\n*** SQL statement: "..sql.."\n", 5, 10);
		return false;
	end;

	-- Check if types table is empty.
	sql = "SELECT * FROM "..set_db_types;
	res, count = SQ(sql);
	if (count == 0) then
		-- Table empty, add pre-set types.
		values = "('movies'),('music'),('docs'),('games'),('anime'),('manga'),('progs'),('pics')";
		sql = "INSERT INTO "..set_db_types.." (type) VALUES "..values
		res, err = SQ(sql);

		-- Check if insertion was successful.
		if (not res) then
			-- Data insertion failed, send error message.
			MsgMain("\n*** Error!\n*** Could not seed table: "..set_db_types..".", 5, 10);
			MsgMain("\n*** Error message was: "..err.."\n*** SQL statement: "..sql.."\n", 5, 10);
			return false;
		end;
	end;

	-- Create Top-10 userlists table.
	db_fields = " (nick VARCHAR(60) NOT NULL, f1 MEDIUMINT(8) UNSIGNED, r1 TINYINT(1) NOT NULL, "..
			"f2 MEDIUMINT(8) UNSIGNED, r2 TINYINT(1) NOT NULL, f3 MEDIUMINT(8) UNSIGNED, r3 TINYINT(1) NOT NULL, "..
			"f4 MEDIUMINT(8) UNSIGNED, r4 TINYINT(1) NOT NULL, f5 MEDIUMINT(8) UNSIGNED, r5 TINYINT(1) NOT NULL, "..
			"f6 MEDIUMINT(8) UNSIGNED, r6 TINYINT(1) NOT NULL, f7 MEDIUMINT(8) UNSIGNED, r7 TINYINT(1) NOT NULL, "..
			"f8 MEDIUMINT(8) UNSIGNED, r8 TINYINT(1) NOT NULL, f9 MEDIUMINT(8) UNSIGNED, r9 TINYINT(1) NOT NULL, "..
			"f0 MEDIUMINT(8) UNSIGNED, r0 TINYINT(1) NOT NULL, PRIMARY KEY (nick))";
	sql = "CREATE TABLE IF NOT EXISTS "..set_db_top..db_fields;
	res, err = SQ(sql);

	-- Check if creation was successful.
	if (not res) then
		-- Table creation failed, send error message.
		MsgMain("\n*** Error!\n*** Could not create table: "..set_db_top..".", 5, 10);
		MsgMain("*** Error message was: "..err.."\n*** SQL statement: "..sql.."\n", 5, 10);
		return false;
	end;

	-- Table created, send "ok" message.
--	MsgMain("\n*** ListBot is up and running, and ready for commands.", 10, 10);
	return 1;
end;

-- Is executed when a user connects to the HUB.
function VH_OnUserLogin(nick)
	-- Check if "Connecting News" is turned on.
	if (set_us_news) then
		-- On, send news-list to user.
		ListNew(nick);
	end;

	-- Check if menu is to be sent.
	if (set_us_menu) then
		-- Set the title to be used for the menu-entry.
		--local title = ".:: ListBot";
		-- Check what prefix to use.
		if (IsClass(nick, 3)) then
			prefix = "!";
		else
			prefix = "+";
		end;

		-- Create and send menu.
		MenuOpt(nick, set_bot_menu, "Show last "..set_no_news.." files", prefix.."list new");
		MenuOpt(nick, set_bot_menu, "List all files", prefix.."list all");
		MenuOpt(nick, set_bot_menu, "Show a range of files", prefix.."list range %[line:Minimum file ID ?] %[line:Maximum file ID ?]");
		MenuOpt(nick, set_bot_menu, "List files of type #", prefix.."list %[line:Enter a type ID]");
		MenuDiv(nick);
		MenuOpt(nick, set_bot_menu, "Add a file", prefix.."fadd %[line:Enter destination type ID(!list types to show types)] %[line:The title. Use Quote if Space!] %[line:The filename. Use Quote if Space!] %[line:Path to file. Use Quote if Space!] %[line:Comment, smiley and links allowed! Use Quote if Space!]");
		MenuOpt(nick, set_bot_menu, "Change type of file", prefix.."ctype %[line:File ID] %[line:New type ID]");
		MenuOpt(nick, set_bot_menu, "Delete a file", prefix.."fdel %[line:ID of file to delete?]");
		MenuDiv(nick);
		MenuOpt(nick, set_bot_menu, "List all types", prefix.."list types");
		MenuOpt(nick, set_bot_menu, "Add a new type", prefix.."ntype %[line:Enter a new type name]");
		MenuOpt(nick, set_bot_menu, "Delete a type", prefix.."dtype %[line:**WARNING** Deletes all associated files!]");
		MenuDiv(nick);
		MenuOpt(nick, set_bot_menu, "Display top-10 list", prefix.."ltop %[line:User's nick, empty for your own list]");
		MenuOpt(nick, set_bot_menu, "Add new top-10 file", prefix.."atop %[line:Enter file ID] %[line:Enter score (1 - (1)0)]");
		MenuOpt(nick, set_bot_menu, "Rank a top-10 file", prefix.."rtop %[line:Enter file ID] %[line:Enter new score (1 - (1)0)]");
		MenuOpt(nick, set_bot_menu, "Remove a top-10 file", prefix.."dtop %[line:Enter file ID]");
		MenuDiv(nick);
		MenuOpt(nick, set_bot_menu, "Help for ListBot", prefix.."help_files");

		-- Check if user is HUB admin, or higher.
		if (IsClass(nick, 5)) then
			-- User is admin, create and send configuration menu.
			MenuDiv(nick);
			MenuOpt(nick, set_bot_menu, "Toggle OP alert ON/OFF", prefix.."lbs alert");
			MenuOpt(nick, set_bot_menu, "Toggle News on connection", prefix.."lbs news");
			MenuOpt(nick, set_bot_menu, "Set number of news", prefix.."lbs newsno %[line:Number of news to show in list]");
			MenuOpt(nick, set_bot_menu, "Toggle send this menu", prefix.."lbs menu");
			MenuOpt(nick, set_bot_menu, "Toggle Top-10 lists", prefix.."lbs top10");
			MenuOpt(nick, set_bot_menu, "Set Top-10 class", prefix.."lbs usetop %[line:Class of users allowed to have Top-10 lists]");
			MenuOpt(nick, set_bot_menu, "Toggle use URL", prefix.."lbs webuse");
			MenuOpt(nick, set_bot_menu, "Set base URL", prefix.."lbs webpath %[line:Base path for URLs]");
		end;
	end;

	-- Continue parsing.
	return 1;
end;

-- Is executed when somone triggers a "!" command.
function VH_OnOperatorCommand(nick, data)
	-- Check for, and execute, commands.
	ret = Check_Commands(nick, data);

	-- Check if command succeeded.
	if (ret == 1 or (ret == 2 and use_existing_bot and use_existing_bot ~= 0)) then
		-- Command succeeded, and no further parsing needed.
		return 0;
	end;

	-- Continue parsing.
	return 1;
end;

-- Executed on all user commands ("+" commands).
function VH_OnUserCommand(nick, data)
	-- Check for, and execute, commands.
	ret = Check_Commands(nick, data);

	-- Check if command succeeded.
	if (ret == 1 or (ret == 2 and use_existing_bot and use_existing_bot ~= 0)) then
		-- Command succeeded, and no further parsing needed.
		return 0;
	end;

	-- Continue parsing.
	return 1;
end;

-- Grab all PMs sent on HUB.
function VH_OnParsedMsgPM(nick, data, to)
	-- Check if PM is sent to bot.
	if (to == set_bot_name) then
		-- PM sent to bot. Check for, and execute, commands.
		ret = Check_Commands(nick, data);

		-- Check if command succeeded, and if extra bot was added.
		if (ret == 0 and (not use_existing_bot or use_existing_bot == 0)) then
			-- Send "command not found" to user, and abort.
			MsgPm(nick, "Warning! Command not found, please try again.");
		elseif (ret == 1 or (ret == 2 and use_existing_bot and use_existing_bot ~= 0)) then
			-- Command succeeded, and no further parsing needed.
		else
			-- No commands passed, show warning.
			MsgPm(nick, "Warning! This bot will only accept certain commands, please write '!help' and try again.");
		end;

		-- Was to bot, so stop parsing to save resources.
		return 0;
	end;

	-- Continue parsing.
	return 1;
end;

-- Checks for commands.
function Check_Commands(nick, data)
	-- Define local variables, for later use.
	local fi, ti;

	-- Check if user is HUB admin, or higher.
	if (IsClass(nick, 5)) then
		-- User is of admin-class, or higher, check what command was used.
		if (string.find(data, "^[%+!]lbs")) then
			-- Configure command called, parse data and call function.
			_, _, data = string.find(data, "[%+!]lbs%s([%w ]+)");
			SetConfig(nick, data);
			return 1;
		end;
	end;

	-- Check if user is of "admin" class.
	if (IsClass(nick, set_cls_admin)) then
		-- User has access to "admin" commands, check what command was used.
		if (string.find(data, "^[%+!]fadd%s")) then
			-- Requested file-add, call function.
			AddFile(nick, data);
			return 1;
		end;

		if (string.find(data, "^[%+!]fdel%s")) then
			-- Requested file-deletion, sort variables and call function.
			_, _, data = string.find(data, "[%+!]fdel%s(%d+)");
			DelFile(nick, data);
			return 1;
		end;

		if (string.find(data, "^[%+!]ntype%s")) then
			-- Requested new type, sort variables and call function.
			_, _, data = string.find(data, "[%+!]ntype%s(%w+)");
			AddType(nick, data);
			return 1;
		end;

		if (string.find(data, "^[%+!]ctype%s")) then
			-- Requsted type-change, get file ID + type ID and call function.
			_, _, fi, ti = string.find(data, "[%+!]ctype%s(%d+)%s(%d+)");
			ChangeType(nick, fi, ti);
			return 1;
		end;

		if (string.find(data, "^[%+!]dtype%s")) then
			-- Requested deletion of type, sort variables and call function.
			_, _, data = string.find(data, "[%+!]dtype%s([%w%d]+)");
			DelType(nick, data);
			return 1;
		end;
	end;

	-- Check if user is of "user" class.
	if (IsClass(nick, set_cls_user)) then
		-- User has access to "user" commands, check what command was used.
		if (string.find(data, "^[%+!]"..set_cmd_help)) then
			-- User asked for help, get prefix and send help-message for bot.
			_, _, data = string.find(data, "([%+!])"..set_cmd_help);
			MsgHelp(nick, data);
			return 1;
		end;

		if (string.find(data, "^[%+!]list types")) then
			-- User requested type list, call function.
			ListTypes(nick);
			return 1;
		end;

		if (string.find(data, "^[%+!]list new")) then
			-- User requested newest added list, call function.
			ListNew(nick);
			return 1;
		end;

		if (string.find(data, "^[%+!]list range")) then
			-- User requested ranged list, get parametres and call function.
			_, _, data = string.find(data, "[%+!]list%s(range%s%d+%s%d+)");
			ListFiles(nick, data);
			return 1;
		end;

		if (string.find(data, "^[%+!]list%s")) then
			-- User requested list, get type and call list-function.
			_, _, data = string.find(data, "[%+!]list%s([%d%w ]+)");
			ListFiles(nick, data);
			return 1;
		end;

		if (data == "+help" or data == "!help") then
			-- User asked for help, get prefix and add help-message for bot.
			_, _, data = string.find(data, "([%+!])help");
			MsgHelp(nick, data);
			return 0;
		end;

		-- Check if Top-10 list is activated
		if (set_use_top10) then
			-- Activated, check what command was used.
			if (string.find(data, "^[%+!]ltop")) then
				-- Asking for Top-10 list, call function.
				ListTop(nick, data);
				return 1;
			end;

			if (string.find(data, "^[%+!]atop%s")) then
				-- Adding file to Top-10 list, call function.
				AddTop(nick, data);
				return 1;
			end;

			if (string.find(data, "^[%+!]dtop%s")) then
				-- Removing file from Top-10 list, parse data and call function.
				_, _, data = string.find(data, "dtop%s(%d+)");
				DelTop(nick, data);
				return 1;
			end;

			if (string.find(data, "^[%+!]rtop%s")) then
				-- Changing score of file in Top-10 list, call function.
				RankTop(nick, data);
				return 1;
			end;
		end;
	end;
end;

-- Toggle configuration variables.
function SetConfig(user, rule)
	-- Define local variables, for later use.
	local message, val, temp;

	-- Split "rule" into "name" and "value", if last one is set.
	_, _, temp, val = string.find(rule, "(%w+)%s?([%w%d]*)");

	-- Check if rule name was found.
	if (temp and temp ~= "") then
		-- Found, set rule name correctly.
		rule = temp;
	end;

	-- Check what rule to toggle.
	if (rule == "alert") then
		-- OP alert found, check status.
		if (set_op_alert == true) then
			-- Op alert active, turn off and set correct message.
			set_op_alert = false;
			message = "OP alert is now [OFF]!";
		else
			-- Op alert not active, turn on and set correct message.
			set_op_alert = true;
			message = "OP alert is now [ON]!";
		end;
	elseif (rule == "news") then
		-- Connecting news found, check status.
		if (set_us_news == true) then
			-- Connecting news active, turn off and set correct message.
			set_us_news = false;
			message = "PM news to connecting users is now [OFF]!";
		else
			-- Connecting news not active, turn on and set correct message.
			set_us_news = true;
			message = "PM news to connecting users is now [ON]!";
		end;
	elseif (rule == "newsno") then
		-- News number rule found, check if "value" has been set.
		if (not val or not tonumber(val)) then
			-- Not set, set warning and abort.
			message = "*** Warning! No valid value set, please try again.";
		else 
			-- Update the global variable, and set correct mesasge.
			set_no_news = val;
			message = "Number of news set to '"..val.."' successfully.";
		end;
	elseif (rule == "menu") then
		-- Right-click menu found, check status.
		if (set_us_menu == true) then
			-- Right-click menu active, turn off and set correct message.
			set_us_menu = false;
			message = "Right-click menu is now [OFF]!";
		else
			-- Right-click menu not active, turn on and set correct message.
			set_us_menu = true;
			message = "Right-click menu is now [ON]!";
		end;
	elseif (rule == "top10") then
		-- Top-10 lists found, check status.
		if (set_use_top10 == true) then
			-- Top-10 lists active, turn off and set correct message.
			set_use_top10 = false;
			message = "Top-10 lists are now [OFF]!";
		else
			-- Top-10 lists not active, turn on and set correct message.
			set_use_top10 = true;
			message = "Top-10 lists are now [ON]!";
		end;
	elseif (rule == "usetop") then
		-- Top-10 user class found, check if "value" has been set.
		if (not val or not tonumber(val)) then
			-- Not set, set warning and abort.
			message = "*** Warning! No valid value set, please try again.";
		else 
			-- Update the global variable, and set correct mesasge.
			set_cls_top = val;
			message = "Top-10 user class set to '"..val.."' successfully.";
		end;
	elseif (rule == "webuse") then
		-- Web-use toggle found, check status.
		if (set_wh_use == true) then
			-- Web-path use active, turn off and set correct message.
			set_wh_use = false;
			message = "Web-path use is now [OFF]!";
		else
			-- Web-path use not active, turn on and set correct message.
			set_wh_use = true;
			message = "Web-path use is now [ON]!";
		end;
	elseif (rule == "webpath") then
		-- Web-path rule is found, check if "value" has been set.
		if (not val or val == "") then
			-- Not set, set warning and abort.
			message = "*** Warning! No valid value set, please try again.";
		else
			-- Check if the string starts with "HTTP://".
			if (string.sub(val, 1, 7) == "http://") then
				-- Remove "http://" from the beginning, and set the variable.
				val = string.sub(val, 8);
			end;

			-- Check if the string ends with "/".
			if (string.sub(val, -1) == "/") then
				-- Remove last char.
				val = string.sub(val, 1, -2);
			end;

			-- Update the global variable, and set correct message.
			set_wh_path = val;
			message = "Web-path is set to '"..val.."' successfully.";
		end;
	else
		-- No, or unknown, rule name passed: Show warning.
		message = "Error! Unkown or missing rule filter, please try again.";
	end;

	-- Send message to user.
	MsgUser(user, message);
end;

-- Displays user's Top-10 list
function ListTop(user, list)
	-- Declare local variables, for later use.
	local sql, db_fields, res, rows, err, rows;
	local f, r = {}, {};

	-- Retrieve and check if spesific user's list was requested.
	_, _, list = string.find (list, "ltop%s([^;\"%$%|]*)");
	if (not list or list == "") then
		-- No parametre passed, set list to current user.
		list = user
	end;

	-- Retrieve Top-10 list from database.
	db_fields = "f1, r1, f2, r2, f3, r3, f4, r4, f5, r5, f6, r6, f7, r7, f8, r8, f9, r9, f0, r0";
	sql = "SELECT "..db_fields.." FROM "..set_db_top.." WHERE nick=\""..list.."\"";
	res, rows = SQ(sql);

	-- Check if query was successful.
	if (not res) then
		-- Failed, show error and abort.
		message = "*** Error!\nCould not retrieve Top-10 list from database.\n"..
				"Error message was:"..rows.."\nSQL statement: "..sql;
		MsgPm(user, "Error! Failed to list Top-10 file due to SQL error, admins have been notified.");
		MsgOps(set_bot_name, message, 5);
		return false;
	elseif (rows == 0) then
		-- No rows, show warning and abort.
		MsgPm(user, "Warning! The user \""..list.."\" doesn't seem to have a Top-10 list, please verify and try again.");
		return 1;
	end;

	-- Retrieve the results.
	res, f[1], r[1], f[2], r[2], f[3], r[3], f[4], r[4], f[5], r[5], f[6], r[6], f[7], r[7], f[8], r[8], f[9], r[9], f[10], r[10] = SF(0);

	-- Check if retrieval was successful.
	if (not res) then
		-- Failed, show error and abort.
		message = "*** Error!\nCould not retrieve Top-10 query results.\n"..
				"Error message was:"..file[1].."\nSQL statement: "..sql;
		MsgPm(user, "Error! Failed to list Top-10 file due to SQL error, admins have been notified.");
		MsgOps(set_bot_name, message, 5);
		return false;
	end;

	-- TODO:
	-- Sort arrays based upon rank.

	-- Start building list.
	message = "\n"..set_str_lim.."\n\t*** Top-10 list for '"..list.."':\n"..set_str_lim.."\n";

	-- Run through the files.
	for run = 1, 10 do
		-- Cast File ID to number.
		f[run] = tonumber(f[run]);

		-- Check if file data is set, and if file has correct ID.
		if (f[run] and f[run] ~= 0) then
			-- File is set, retrieve file details.
			sql = "SELECT f.title, f.type, t.type, f.file, f.path, f.comment, f.adder FROM "..set_db_table.." AS f "..
				"LEFT JOIN "..set_db_types.." AS t ON t.id = f.type WHERE f.id="..f[run];
			res, val = SQ(sql);

			-- Check if retrieval was successful.
			if (not res) then
				-- Failed, sending error to user and admins.
				message = "*** Error!\nCould not retrieve file-list from database.\n"..
						"Error message was:"..val.."\nSQL statement: "..sql;
				MsgPm(user, "Error! Cound not retrieve data due to SQL error, admins have been notified.");
				MsgOps(set_bot_name, message, 5);
				return false;
			end;

			-- Get row from table.
			_, ft, ti, tn, fn, fp, fc, ad = SF(0);

			-- Check if path is set.
			if (not fp) then
				-- Path is not set, set to empty string to avoid errors.
				fp = "";
			elseif (set_wh_use) then
				-- Path is set and web-path is to be used, verify that "path" conforms with syntax.
				if (string.find(fp, "\\", 1, 1)) then
					-- Does not, replace all backslashes into slash.
					path = string.gsub(fp, "\\", "/");
				end;

				-- Check if path starts with a slash.
				if (string.sub(fp, 1, 1) ~= "/") then
					-- Does not, add one.
					fp = "/"..fp;
				end;

				-- Check to see if path ends witha slash.
				if (string.sub(fp, -1) ~= "/") then
					-- Does not, add one.
					fp = fp.."/";
				end;

				-- Checks to see if filename starts with either slash.
				if (string.sub(fn, 1, 1) == "/" or string.sub(fn, 1, 1) == "\\") then
					-- Does, remove it.
					fn = string.sub(fn, 2);
				end;

				-- Build the URL line.
				url = fp.."\n\tURL: http://"..set_wh_path..fp..fn;
				fp = url;
			end;

			-- Check if comment is set.
			if (not fc) then
				-- Comment is not set, set to empty string to avoid errors.
				fc = "";
			end;

			-- Check if string type was retrieved.
			if (not tn or tn == "") then
				-- String type not set, set to ID for missing type.
				tn = ti;
			end;

			-- Add file to list.
			message = message.."** Rank #"..r[run]..":  \""..ft.."\"  in ("..tn..")   Poster: [ "..ad..
				" ]\n\tFile ID: "..f[run].."\n\tFilename: "..fn.."\n\tPath: "..fp.."\n\tComment: "..fc.."\n\n";
		end;
	end;

	-- Send message, and return successfully.
	MsgPm(user, message..set_str_lim);
	return 1;
end;

-- Adds given file to users Top-10 list.
function AddTop(user, data)
	-- Define local variables, for later use.
	local message, sql, rows, err, res, fid, score, found, pos;
	local file = {};

	-- Check if user has access to Top-10 classs.
	if (not IsClass(user, set_cls_top)) then
		-- User lacks access, show warning and abort.
		MsgPm("Warning! You do not have sufficient access to use this command, please contact an OP if you want a Top-10 list.");
		return 1;
	end;

	-- Split file-id and score from data.
	_, _, fid, score = string.find(data, "(%d+)%s(%d)");

	-- Check if file ID and new score has been set.
	if (not fid or not score) then
		-- Not set, send warning to user and abort.
		MsgPm(user, "Warning! File ID/score not set, or invalid. Please try again.");
		return 1;
	end;

	-- Retrieve details on existing list.
	sql = "SELECT f1, f2, f3, f4, f5, f6, f7, f8, f9, f0 FROM "..set_db_top.." WHERE nick=\""..user.."\"";
	res, rows = SQ(sql);

	-- Check if retrieval was successful.
	if (not res) then
		-- Failed, show error and abort.
		message = "*** Error!\nCould not retrieve Top-10 list from database.\n"..
				"Error message was:"..rows.."\nSQL statement: "..sql;
		MsgPm(user, "Error! Failed to add Top-10 file due to SQL error, admins have been notified.");
		MsgOps(set_bot_name, message, 5);
		return false;
	end;

	-- Check if user has an existing list.
	if (rows == 0) then
		-- No existing list, set SQL to create it.
		sql = "INSERT INTO "..set_db_top.." (nick, f1, r1) VALUES (\""..user.."\", "..fid..", "..score..")";
	else
		-- Existing list found, retrieve the results.
		res, file[1], file[2], file[3], file[4], file[5], file[6], file[7], file[8], file[9], file[10] = SF(0);

		-- Check if retrieval was successful.
		if (not res) then
			-- Failed, show error and abort.
			message = "*** Error!\nCould not retrieve Top-10 query results.\n"..
					"Error message was:"..file[1].."\nSQL statement: "..sql;
			MsgPm(user, "Error! Failed to add Top-10 file due to SQL error, admins have been notified.");
			MsgOps(set_bot_name, message, 5);
			return false;
		end;

		-- Run through results, and check if there is an available spot.
		for run = 1, 10 do
			-- Cast file ID to number.
			file[run] = tonumber(file[run]);

			-- Check if file ID is set.
			if (not file[run] or file[run] == 0) then
				-- Flag available spot found, and break loop.
				pos = run;
				found = true;
				break;
			end;
		end;

		-- Check if available spot was found.
		if (not found) then
			-- Not found, show warning and abort.
			MsgPm("Warning! No available file entry found, please delete a file and try again.");
			return 1;
		end;

		-- Verify pos.
		if (pos == 10) then
			-- Pos is 10, set to 0 for compability.
			pos = 0;
		end;

		-- Set SQL to insert data at next available spot.
		sql = "UPDATE "..set_db_top.." SET f"..pos.."="..fid..", r"..pos.."="..score.." WHERE nick=\""..user.."\"";
	end;

	-- Add new file to user's Top-10 list.
	res, err = SQ(sql);

	-- Check if addition was successful.
	if (not res) then
		-- Failed, show error and abort.
		message = "*** Error!\nCould not insert new Top-10 file into database.\n"..
				"Error message was:"..err.."\nSQL statement: "..sql;
		MsgPm(user, "Error! Failed to add Top-10 file due to SQL error, admins have been notified.");
		MsgOps(set_bot_name, message, 5);
		return false;
	end;

	-- Show confirmation message, and return successfully.
	MsgPm(user, "Success! New file of id #"..fid.." added to your Top-10 list, with a score of '"..score.."'.");
	return 1;
end;

-- Changes the score of given file in users Top-10 list.
function RankTop(user, data)
	-- Define local variables, for later use.
	local message, sql, err, res, rows, fid, score, found, pos;
	local file = {};

	-- Check if user has access to Top-10 classs.
	if (not IsClass(user, set_cls_top)) then
		-- User lacks access, show warning and abort.
		MsgPm("Warning! You do not have sufficient access to use this command, please contact an OP if you want a Top-10 list.");
		return 1;
	end;

	-- Split file-id and score from data.
	_, _, fid, score = string.find(data, "(%d+)%s(%d)");

	-- Check if file ID and new score has been set.
	if (not fid or not score) then
		-- Not set, send warning to user and abort.
		MsgPm(user, "Warning! File ID/score not set, or invalid. Please try again.");
		return 1;
	end;

	-- Get user's list details from Top-10 table..
	sql = "SELECT f1, f2, f3, f4, f5, f6, f7, f8, f9, f0 FROM "..set_db_top.." WHERE nick=\""..user.."\"";
	res, rows = SQ(sql);

	-- Check if query was successful, and user's list exists.
	if (not res) then
		-- Failed, show error and abort.
		message = "*** Error!\nCould not retrieve Top-10 list from database.\n"..
				"Error message was:"..rows.."\nSQL statement: "..sql;
		MsgPm(user, "Error! Failed to update score of Top-10 file due to SQL error, admins have been notified.");
		MsgOps(set_bot_name, message, 5);
		return false;
	elseif (rows == 0) then
		-- No rows, show warning and abort.
		MsgPm(user, "Warning! You don't seem to have a Top-10 list, please add at least one file to it before using this command.");
		return 1;
	end;

	-- Retrieve the results.
	res, file[1], file[2], file[3], file[4], file[5], file[6], file[7], file[8], file[9], file[0] = SF(0);

	-- Check if retrieval was successful.
	if (not res) then
		-- Failed, show error and abort.
		message = "*** Error!\nCould not retrieve Top-10 query results.\n"..
				"Error message was:"..file[1].."\nSQL statement: "..sql;
		MsgPm(user, "Error! Failed to remove Top-10 file due to SQL error, admins have been notified.");
		MsgOps(set_bot_name, message, 5);
		return false;
	end;

	-- Set default message.
	message = "Warning! Could not find given file-ID in your Top-10 list, please verify it and try again.";

	-- Check if File ID is in user's Top-10 list.
	for run = 0, 9 do
		-- Check if file data is set, and if file has correct ID.
		if (file[run] and file[run] ~= "" and file[run] == fid) then
			-- Flag file to be found, and break loop.
			pos = run;
			found = true;
			break;
		end;
	end;

	-- Check if the file ID was found.
	if (found) then
		-- Found, set new score.
		sql = "UPDATE "..set_db_top.." SET r"..pos.."="..score.." WHERE nick=\""..user.."\"";
		res, err = SQ(sql);

		-- Check if update succeeded.
		if (not res) then
			-- Failed, show error and abort.
			message = "*** Error!\nCould not update score of Top-10 file.\n"..
					"Error message was:"..err.."\nSQL statement: "..sql;
			MsgPm(user, "Error! Failed to update score of Top-10 file due to SQL error, admins have been notified.");
			MsgOps(set_bot_name, message, 5);
			return false;
		end;

		-- Update message to show success.
		message = "Success! Updated file with id #"..fid.." in your Top-10 list, changed score to '"..score.."'.";
	end;

	-- Show message, and return.
	MsgPm(user, message);
	return 1;
end;

-- Removes a file from user's Top-10 list.
function DelTop(user, fid)
	-- Define local variables, for later use.
	local message, sql, err, rows, res, pos;
	local file = {};

	-- Check if user has access to Top-10 classs.
	if (not IsClass(user, set_cls_top)) then
		-- User lacks access, show warning and abort.
		MsgPm("Warning! You do not have sufficient access to use this command, please contact an OP if you want a Top-10 list.");
		return 1;
	end;

	-- Convert fid to number.
	fid = tonumber(fid);

	-- Check if file ID has been set.
	if (not fid) then
		-- Not set, send warning to user and abort.
		MsgPm(user, "Warning! File ID not set, or invalid. Please try again.");
		return 1;
	end;

	-- Get user's list details from Top-10 table..
	sql = "SELECT f1, f2, f3, f4, f5, f6, f7, f8, f9, f0 FROM "..set_db_top.." WHERE nick=\""..user.."\"";
	res, rows = SQ(sql);

	-- Check if query was successful, and user's list exists.
	if (not res) then
		-- Failed, show error and abort.
		message = "*** Error!\nCould not retrieve Top-10 list from database.\n"..
				"Error message was:"..rows.."\nSQL statement: "..sql;
		MsgPm(user, "Error! Failed to remove Top-10 file due to SQL error, admins have been notified.");
		MsgOps(set_bot_name, message, 5);
		return false;
	elseif (rows == 0) then
		-- No rows, show warning and abort.
		MsgPm(user, "Warning! You don't seem to have a Top-10 list, please add at least one file to it before using this command.");
		return 1;
	end;

	-- Retrieve the results.
	res, file[1], file[2], file[3], file[4], file[5], file[6], file[7], file[8], file[9], file[10] = SF(0);

	-- Check if retrieval was successful.
	if (not res) then
		-- Failed, show error and abort.
		message = "*** Error!\nCould not retrieve Top-10 query results.\n"..
				"Error message was:"..file[1].."\nSQL statement: "..sql;
		MsgPm(user, "Error! Failed to remove Top-10 file due to SQL error, admins have been notified.");
		MsgOps(set_bot_name, message, 5);
		return false;
	end;

	-- Set default message.
	message = "Warning! Could not find given file-ID in your Top-10 list, please verify it and try again.";

	-- Run through the files.
	for run = 1, 10 do
		-- Check if file data is set, and if file has correct ID.
		if (file[run] and tonumber(file[run]) == fid) then
			if (run == 10) then
				pos = 0;
			else
				pos = run;
			end;

			-- File is found, remove it from the table.
			sql = "UPDATE "..set_db_top.." SET f"..pos.."=NULL, r"..pos.." = 0 WHERE nick=\""..user.."\"";
			res, err = SQ(sql);

			-- Check if removal was successful.
			if (not res) then
				-- Removal failed, send error to user and admins.
				message = "*** Error!\nCould not remove Top-10 file!\n"..
						"Error message was:"..val.."\nSQL statement: "..sql;
				MsgPm(user, "Error! Failed to remove Top-10 file due to SQL error, admins have been notified.");
				MsgOps(set_bot_name, message, 5);
				return false;
			end;

			-- Update message to show success.
			message = "Success! Removed file with id #"..fid.." from your Top-10 list.";
			break;
		end;
	end;

	-- Send message, and return successfully.
	MsgPm(user, message);
	return 1;
end;

-- Send list over types to user.
function ListTypes(user)
	-- Define local variables, for later use.
	local res, val, sql, message, tid, fn, count;

	-- Retrieve data from database.
	sql = "SELECT type, id, count FROM "..set_db_types.." ORDER BY id ASC";
	res, val = SQ(sql);

	-- Check if retrieval was successful.
	if (not res) then
		-- Failed, show error to user & admins.
		message = "*** Error!\nCould not retrieve file-types!\n"..
				"Error message was:"..val.."\nSQL statement: "..sql;
		MsgPm(user, "Error! Could not retrieve types due to SQL error, admins have been notified.");
		MsgOps(set_bot_name, message, 5);
		return false;
	end;

	-- Check if there are any file-types available.
	if (val == 0) then
		-- None available, notify user user and return successfuly.
		MsgPm(user, "No file-types available, please try again later.");
		return 1;
	end;

	-- Start building list.
	message = "\n"..set_str_lim.."\n*** Showing types:\n"..set_str_lim.."\n";

	-- Spool through results, and send them to the user.
	for run = 0, val - 1 do
		res, fn, tid, cn = SF(run);
		message = message.."** "..tid.."\t"..fn.."\t("..cn..")\n";
	end;

	-- Send details to user, and return successfully.
	MsgPm(user, message..set_str_lim);
	return 1;
end;

-- Delete types from database.
function DelType(user, ft)
	-- Define local variables, for later use.
	local res, val, sql, message, f_type, found;

	-- Check if ft is set.
	if (not ft or ft == "" or ft == 0) then
		-- File-type not set, send warning to user.
		MsgPm(user, "Warning! File-type not set, or invalid. Please try again with valid input.");
		return false;
	end;

	-- Check if sent file-type is string.
	sql = "SELECT id FROM "..set_db_types.." WHERE type='"..ft.."'";
	res, val = SQ(sql);

	if (not res or val == 0) then
		-- Check if file-type is ID number.
		found, _, f_type = string.find(ft, "(%d+)");
		if (not found) then
			-- Not valid file-type, send warning to user.
			MsgPm(user, "Warning! File-type not set, or invalid. Please try again with valid input.");
			return false;
		end;

		-- Check if ID exists.
		sql = "SELECT id FROM "..set_db_types.." WHERE id="..f_type;
		res, val = SQ(sql);
		if (not res or val == 0) then
			-- ID doesn't exists, send warning to user.
			MsgPm(user, "Warning! File-type not set, or invalid. Please try again with valid input.");
			return false;
		end;
	end;

	-- Get ID to delete.
	res, val = SF(0);

	-- File-type exists, delete from table.
	sql = "DELETE FROM "..set_db_types.." WHERE id="..val;
	res, err = SQ(sql);

	-- Check if deletion was successful.
	if (not res) then
		-- Deletion failed, send error to user and admins.
		message = "*** Error!\nCould not delete file-type!\n"..
				"Error message was:"..val.."\nSQL statement: "..sql;
		MsgPm(user, "Error! Could not delete file-type due to SQL error, admins have been notified.");
		MsgOps(set_bot_name, message, 5);
		return false;
	end;

	-- Check if there are any files to be deleted.
	if (val ~= 0) then
		-- Delete all files of deleted type.
		sql = "DELETE FROM "..set_db_table.." WHERE type="..val;
		res, err = SQ(sql);

		-- Check if deletion was successful.
		if (not res) then
			-- Deletion failed, send error to user and admins.
			message = "*** Error!\nCould not delete files!\n"..
					"Error message was:"..err.."\nSQL statement: "..sql;
			MsgPm(user, "Error! Could not delete file-type due to SQL error, admins have been notified.");
			MsgOps(set_bot_name, message, 5);
			return false;
		end;
	end;

	-- Check if alert all admins.
	if (CheckAlert() == true) then
		-- Alert admins set, send message.
		MsgOps(set_bot_name, "** User \""..user.."\" deleted type \""..ft.."\".", 5);
	end;

	-- Show confirmation message, and return successfully.
	MsgPm(user, "File-type deleted successfully.");
	return 1;
end;

-- Add new type to database.
function AddType(user, ft)
	-- Define local variables, for later use.
	local res, val, err, sql, message;

	-- Check if File-type is set.
	if (ft == "") then
		-- Not set / valid, show error
		MsgPm(user, "Warning! File-type not set, or invalid. Please try again with valid input.");
		return 1;
	end;

	-- Retrieve file-type from database, if it exists.
	sql = "SELECT * FROM "..set_db_types.." WHERE type='"..ft.."'";
	res, val = SQ(sql);

	-- Check if retrieval was successful.
	if (not res) then
		-- Retrieval failed, show error and alert admins.
		message = "*** Error!\nCould not retrieve file-type check data!\n"..
				"Error message was:"..err.."\nSQL statement: "..sql;
		MsgPm(user, "Could not store new type due to SQL error, admins have been notified");
		MsgOps(set_bot_name, message, 5);
		return false;
	end;

	-- Check if type exists already.
	if (val ~= 0) then
		 -- Type already exists, show warning.
		 MsgPm(user, "Warning! File-type already exists, please try again with a unique name.");
		 return 1;
	end;

	-- Add file-type to table.
	sql = "INSERT INTO "..set_db_types.." (type) VALUES ('"..ft.."')";
	res, err = SQ(sql);

	-- Check if successful.
	if (not res) then
		-- Not successful, show error to user & admins.
		message = "*** Error!\nCould not save new file-type: "..ft..".\n"..
				"Error message was:"..val.."\nSQL statement: "..sql;
		MsgPm(user, "Could not store new type due to SQL error, admins have been notified");
		MsgOps(set_bot_name, message, 5);
		return false;
	end;

	-- Check if alert all admins.
	if (CheckAlert() == true) then
		-- Alert admins set, send message.
		MsgOps(set_bot_name, "** User \""..user.."\" added type \""..ft.."\".", 5);
	end;

	-- Show confirmation message, and return successfully.
	MsgPm(user, "New type saved successfuly.");
	return 1;
end;

-- Change the ype of a file.
function ChangeType(user, fid, tid)
	-- Define local variables, for later use.
	local sql, res, err, rows, message;

	-- Check if file ID and new type ID has been set.
	if (not fid or not tid) then
		-- Not set, send warning to user and abort.
		MsgPm(user, "Warning! File and/or type ID not set, or invalid. Please try again.");
		return 1;
	end;

	-- Check if new type ID exists.
	sql = "SELECT id FROM "..set_db_types.." WHERE id="..tid;
	res, rows = SQ(sql);

	-- Check if query was successful.
	if (not res) then
		-- Failed, show error and abort.
		message = "*** Error!\nCould not retrieve new type ID from database.\n"..
				"Error message was:"..rows.."\nSQL statement: "..sql;
		MsgPm(user, "Error! Failed to change type due to SQL error, admins have been notified.");
		MsgOps(set_bot_name, message, 5);
		return false;
	elseif (rows == 0) then
		-- No results found, show warning and abort.
		MsgPm(user, "Warning! Invalid type ID, please try again.");
		return 1;
	end;

	-- Get current type ID.
	sql = "SELECT type FROM "..set_db_table.." WHERE id="..fid;
	res, err = SQ(sql);

	-- Check if query was successful.
	if (not res) then
		-- Failed, show error and abort.
		message = "*** Error!\nCould not retrieve old type ID from database.\n"..
				"Error message was:"..err.."\nSQL statement: "..sql;
		MsgPm(user, "Error! Failed to change type due to SQL error, admins have been notified.");
		MsgOps(set_bot_name, message, 5);
		return false;
	end;

	-- Retrieve SQL result.
	res, val = SF(0);

	-- Check if result was fetched successfully.
	if (not res) then
		-- Failed, show error and abort.
		message = "*** Error!\nCould not fetch old type ID result.\n"..
				"Error message was:"..val.."\nSQL statement: "..sql;
		MsgPm(user, "Error! Failed to change type due to SQL error, admins have been notified.");
		MsgOps(set_bot_name, message, 5);
		return false;
	end;

	-- Set new type + 1.
	sql = "UPDATE "..set_db_types.." SET count=count+1 WHERE id="..tid;
	res, err = SQ(sql);

	-- Check if result was fetched successfully.
	if (not res) then
		-- Failed, show error and abort.
		message = "*** Error!\nCould not increase new type count.\n"..
				"Error message was:"..err.."\nSQL statement: "..sql;
		MsgPm(user, "Error! Failed to change type due to SQL error, admins have been notified.");
		MsgOps(set_bot_name, message, 5);
		return false;
	end;

	-- Set current type - 1.
	sql = "UPDATE "..set_db_types.." SET count=count-1 WHERE id="..val;
	res, err = SQ(sql);

	-- Check if result was fetched successfully.
	if (not res) then
		-- Failed, show error and abort.
		message = "*** Error!\nCould not decrease old type count.\n"..
				"Error message was:"..err.."\nSQL statement: "..sql;
		MsgPm(user, "Error! Failed to change type due to SQL error, admins have been notified.");
		MsgOps(set_bot_name, message, 5);
		return false;
	end;

	-- Build and execute SQL-query.
	sql = "UPDATE "..set_db_table.." SET type="..tid.." WHERE id="..fid;
	res, err = SQ(sql);

	-- Check if query was successful.
	if (not res) then
		-- Failed, show error and abort.
		message = "*** Error!\nCould not update file-type.\n"..
				"Error message was:"..val.."\nSQL statement: "..sql;
		MsgPm(user, "Error! Failed to change type due to SQL error, admins have been notified.");
		MsgOps(set_bot_name, message, 5);
		return false;
	end;

	-- Show confirmation message.
	MsgPm(user, "Successfully changed type of file '"..fid.."' to type: "..tid..".");
end;

-- Show help-message to user.
function MsgHelp (user, prefix)
	-- Define local variables, for later use.
	local help;

	-- Build help-message.
	help = "\n"..set_str_lim..set_str_lim.."\nCommands for use with this bot:\n"..
		prefix..set_cmd_help.."\t\tShows this help-page.\n"..
		prefix.."list <type_id>\tShows a list over all items of given <type_id>.\n"..
		prefix.."list types\t\tShows a list over all types, and their ID number.\n"..
		prefix.."list new\t\tShows a list over the 10 newest files added.\n"..
		prefix.."list all\t\tShows a list over all files in the database.\n"..
		prefix.."list range <S> <E>\tLists all files between ID \"S\" and \"E\", including.\n\n"..
		prefix.."ltop [nick]\tShows Top-10 list for user, your own if no nick is supplied.\n";

	-- Check if user has access to Top-10 commands.
	if (IsClass(user, set_cls_top)) then
		-- User has access, add help for Top-10 manipulation commands.
		help = help..prefix.."atop <fid> <rank>\tAdd a new file to your Top-10 list. Score 1=highest, 0=lowest.\n"..
			prefix.."rtop <fid> <rank>\tChange the rank of a file in your Top-10 list.\n"..
			prefix.."dtop <fid>\tDelete file from your Top-10 list.\n";
	end;

	-- Check if user has access to commands admin-commands.
	if (IsClass(user, set_cls_admin)) then
		-- User has access, add help for admin-functions.
		help = help.."\n"..prefix.."ntype <type>\tAdds a new type with <type> as it's name.\n"..
			prefix.."dtype <type_id>\t*WARNING* Deletes the type with the given ID, and all the files associated with that ID.\n"..
			prefix.."ctype <fid> <tid>\tChange type of file \"fid\" to type with id \"tid\".\n"..
			prefix.."fadd <type_id> <title> <filename> [path] [comment]\n"..
			"\t\tAdds a new file of the type <type_id>. Type, title and filename are required,\n"..
			"\t\tand must be filled out correctly. The comment is a good place to add the file-size,\n"..
			"\t\tand other various notes about the file. Use quotes if you have space in the fields.\n"..
			prefix.."fdel <file_id>\tDeletes the file with the given ID, to add it again you have to use "..prefix.."fadd.\n";
	end;

	-- Check if user is in HUB admin-class, or greater.
	if (IsClass(user, 5)) then
		-- User has access, add config command help.
		help = help.."\n"..prefix.."lbs <option>\tToggles the given action between ON and OFF, valid options are:\n"..
			"\t\t'menu' for Right-Click menu, 'alert' for OP alert, 'news' for PM news to connecting users.\n"..
			"\t\t'webuse' to add URLs in lists, 'webpath' to set the domain, 'newno' to set the # of news in \"!list new\".\n";
	end;

	-- Delimit string, accordingly to format.
	help = help..set_str_lim..set_str_lim;

	-- Send help message to user, and return successfully.
	MsgPm(user, help);
	return 1;
end;

-- List the 10 newest files.
function ListNew(user)
	-- Define local variables, for later use.
	local val, res, sql, run, url, message;
	local id, ft, tn, fn, fp, fc, ad, ti;

	-- Retrieve files from database, use "JOIN LEFT" for type.
	sql = "SELECT f.id, f.title, f.type, t.type, f.file, f.path, f.comment, f.adder FROM "..set_db_table.." AS f "..
		"LEFT JOIN "..set_db_types.." AS t ON t.id = f.type ORDER BY id DESC LIMIT "..set_no_news;
	res, val = SQ(sql);

	-- Check if retrieval was successful.
	if (not res) then
		-- Failed, sending error to user and admins.
		message = "*** Error!\nCould not retrieve file-list from database.\n"..
				"Error message was:"..val.."\nSQL statement: "..sql;
		MsgPm(user, "Error! Cound not retrieve data due to SQL error, admins have been notified.");
		MsgOps(set_bot_name, message, 5);
		return false;
	end;

	-- Check if any files have been added.
	if (val == 0) then
		 -- No files added, return notice to user.
		 MsgPm(user, "** No files in database, please try again later.");
		 return 1;
	end;

	-- Start building list.
	message = "\n"..set_str_lim.."\n\t*** Showing "..set_no_news.." newest files:\n"..set_str_lim.."\n";

	-- Spool through the results, and PM them to the requesting. With URL.
	for run = 0, val - 1 do
		-- Get row from table.
		_, id, ft, ti, tn, fn, fp, fc, ad = SF(run);

		-- Check if path is set.
		if (not fp) then
			-- Path is not set, set to empty string to avoid errors.
			fp = "";
		elseif (set_wh_use) then
			-- Path is set and web-path is to be used, verify that "path" conforms with syntax.
			if (string.find(fp, "\\", 1, 1)) then
				-- Does not, replace all backslashes into slash.
				path = string.gsub(fp, "\\", "/");
			end;

			-- Check if path starts with a slash.
			if (string.sub(fp, 1, 1) ~= "/") then
				-- Does not, add one.
				fp = "/"..fp;
			end;

			-- Check to see if path ends witha slash.
			if (string.sub(fp, -1) ~= "/") then
				-- Does not, add one.
				fp = fp.."/";
			end;

			-- Checks to see if filename starts with either slash.
			if (string.sub(fn, 1, 1) == "/" or string.sub(fn, 1, 1) == "\\") then
				-- Does, remove it.
				fn = string.sub(fn, 2);
			end;

			-- Build the URL line.
			url = fp.."\n\tURL: http://"..set_wh_path..fp..fn;
			fp = url;
		end;

		-- Check if comment is set.
		if (not fc) then
			-- Comment is not set, set to empty string to avoid errors.
			fc = "";
		end;

		-- Check if string type was retrieved.
		if (not tn or tn == "") then
			-- String type not set, set to ID for missing type.
			tn = ti;
		end;

		-- Send details to user.
		message = message.."** File #"..id..":  \""..ft.."\"  in ("..tn..")   Poster: [ "..ad..
			" ]\n\tFilename: "..fn.."\n\tPath: "..fp.."\n\tComment: "..fc.."\n\n";
	end;

	-- Send details to user, and return successfully.
	MsgPm(user, message..set_str_lim);
	return 1;
end;

-- List all files from database of type "ft".
function ListFiles(user, ft)
	-- Declare local variables, for later use.
	local err, res, val, sql, run, f_type, message;
	local id, fn, fp, fc, ad, tt, ttype, min, max;

	-- Check if file type is set.
	if (ft == "" or not ft) then
		-- File-type not set, sending error.
		MsgPm(user, "Warning! File-type not set or not a valid type, please try again with a valid input.");
		return false;
	end;

	-- Check what type of query was used.
	if (ft == "all") then
		-- All files requested, build SQL-query.
		sql = "SELECT f.id, t.type, f.title, f.file, f.path, f.comment, f.adder FROM "..set_db_table.." AS f LEFT JOIN "..
			set_db_types.." AS t ON f.type=t.id ORDER BY t.type, f.title";

		-- Set correct type for later on.
		ttype = "all";
	elseif (string.find(ft, "range", 1, 1)) then
		-- Range requested, get lower and upper limit.
		_, _, min, max = string.find(ft, "range%s(%d+)%s(%d+)");

		-- Check if ranges are valid.
		if (not(min and min ~= "" and max and max ~= "")) then
			-- Ranges now valid, show warning to user and abort.
			MsgPm(user, "Warning! Min/max range not set, or invalid. Please try again with valid input.");
			return false;
		end;

		-- Build SQL-query.
		sql = "SELECT f.id, t.type, f.title, f.file, f.path, f.comment, f.adder FROM "..set_db_table.." AS f LEFT JOIN "..
			set_db_types.." AS t ON f.type=t.id WHERE f.id>="..min.." AND f.id<="..max.." ORDER BY t.type, f.title";

		-- Set correct type for later on.
		ttype = "range";
	else
		-- Type listing requested, check if file-type given is number.
		_, _, f_type = string.find(ft, "(%d+)");

		if (f_type and tonumber(ft) == tonumber(f_type)) then
			-- File type is ID, build SQL sentence.
			sql = "SELECT id, type FROM "..set_db_types.." WHERE id="..f_type;
		else
			-- File type is name, build SQL sentence.
			sql = "SELECT id, type FROM "..set_db_types.." WHERE type='"..ft.."'";
		end;

		-- Check if file-type exists.
		res, val = SQ(sql);
		if (not res or val == 0) then
			-- File-type doesn't exist, show error.
			MsgPm(user, "Warning! File-type not set, or invalid. Please try again with valid input.");
			return false;
		end;

		-- Fetch type-ID and type-name.
		res, val, ttype = SF(0);

		-- Build SQL to retrieve all items of type from database.
		sql = "SELECT id, title, file, path, comment, adder FROM "..set_db_table.." WHERE type="..val;
	end;

	-- Execute selected SQL query.
	res, val = SQ(sql);

	-- Check if retrieval was successful.
	if (not res) then
		-- Failed, sending error to user and admins.
		message = "*** Error!\nCould not retrieve file-list from database.\n"..
				"Error message was:"..val.."\nSQL statement: "..sql;
		MsgPm(user, "Error! Could not retrieve data due to SQL error, admins have been notified.");
		MsgOps(set_bot_name, message, 5);
		return false;
	end;

	-- Check if any results were given
	if (val == 0) then
		-- Select correct message.
		if (ttype == "all") then
			-- All files requested.
			message = "** No files in database, please try again later";
		elseif (ttype == "range") then
			-- Range requested.
			message = "Sorry, no files found in that range, please try again.";
		else
			-- Spesific type requested
			message = "Sorry, no files found of that type, please try again later.";
		end;

		-- No results, notify user.
		MsgPm(user, message);
		return 1;
	end;

	-- Check what header to use.
	if (ttype == "range") then
		-- Range requested, build correct list.
		message = "\n"..set_str_lim.."\n*** Showing files from ID "..min.." to "..max..":\n"..set_str_lim.."\n";
	else
		-- Other list requested, build correct list.
		message = "\n"..set_str_lim.."\n*** Showing "..ttype.." files:\n"..set_str_lim.."\n";
		tt = ttype;
	end;

	-- Run through results, and send them to the user. With URL.
	for run = 0, val - 1 do
		-- Check what type of query was used.
		if (ttype == "all" or ttype == "range") then
			-- All files, get correct row from table.
			res, id, tt, ft, fn, fp, fc, ad = SF(run);
		else
			-- Spesific type, get correct row from table.
			res, id, ft, fn, fp, fc, ad = SF(run);
		end;

		-- Check if path is set.
		if (not fp) then
			-- Path is not set, set to empty string to avoid errors.
			fp = "";
		elseif (set_wh_use) then
			-- Path is set and web-path is to be used, verify that "path" conforms with syntax.
			if (string.find(fp, "\\", 1, 1)) then
				-- Does not, replace all backslashes into slash.
				path = string.gsub(fp, "\\", "/");
			end;

			-- Check if path starts with a slash.
			if (string.sub(fp, 1, 1) ~= "/") then
				-- Does not, add one.
				fp = "/"..fp;
			end;

			-- Check to see if path ends witha slash.
			if (string.sub(fp, -1) ~= "/") then
				-- Does not, add one.
				fp = fp.."/";
			end;

			-- Checks to see if filename starts with either slash.
			if (string.sub(fn, 1, 1) == "/" or string.sub(fn, 1, 1) == "\\") then
				-- Does, remove it.
				fn = string.sub(fn, 2);
			end;

			-- Build the URL line.
			url = fp.."\n\tURL: http://"..set_wh_path..fp..fn;
			fp = url;
		end;

		-- Check if comment is set.
		if (not fc) then
			-- Comment is not set, set to empty string to avoid errors.
			fc = "";
		end;

		-- Check if type string is set, and contains data.
		if (not tt or tt == "") then
			-- Failed, populate string with content.
			tt = "<N/A>";
		end;

		-- Create list for showing all files of all types.
		message = message.."** File #"..id..":  \""..ft.."\"  in ("..tt..")   Poster: [ "..ad..
			" ]\n\tFilename: "..fn.."\n\tPath: "..fp.."\n\tComment: "..fc.."\n\n";
	end;

	-- Send details to user, and return successfully.
	MsgPm(user, message..set_str_lim);
	return 1;
end;

-- Deleting file with ID "id" from database.
function DelFile(user, id)
	-- Declare local variables, for later use.
	local res, val, err, sql, message, tid;

	-- Check if ID is set.
	if (id == "" or not id) then
		-- ID not set, send warning to user.
		MsgPm(user, "Warning! File ID not set, or invalid. Please try again with valid input.");
		return false;
	end;

	-- Retrieve ID & type from database for checking purposes & counting reduction.
	sql = "SELECT id, type FROM "..set_db_table.." WHERE id="..id;
	res, val = SQ(sql);

	-- Check if extraction was successful, iow if file exists.
	if (not res or val == 0) then
		-- File didn't exist, send warning to user.
		MsgPm(user, "Warning! File ID not set, or invalid. Please try again with valid input.");
		return false;
	end;

	-- Retrieve SQL result.
	res, id, tid = SF(0);

	-- Check if fetching of values was successful.
	if (not res or not id or not tid) then
		-- Did not retrieve all data, show error to user and admins.
		message = "*** Error!\nCould not fetch id / type data!\n"..
				"Error message was:"..id.."\nSQL statement: "..sql.."\nRow: "..val;
		MsgPm(user, "Error! Could not delete file due to SQL error, admins have been notified.");
		MsgOps(set_bot_name, message, 5);
		return false;
	end;

	-- Reduce type-count by 1.
	sql = "UPDATE "..set_db_types.." SET count = count-1 WHERE id = "..tid;
	res, err = SQ(sql);

	-- Check if reduction was successful.
	if (not res) then
		-- Deletion not successful, show error to user and admins.
		message = "*** Error!\nCould not reduce type-count!\n"..
				"Error message was:"..err.."\nSQL statement: "..sql;
		MsgPm(user, "Error! Could not delete file due to SQL error, admins have been notified.");
		MsgOps(set_bot_name, message, 5);
		return false;
	end;

	-- Delete file from database.
	sql = "DELETE FROM "..set_db_table.." WHERE id = "..id;
	res, err = SQ(sql);

	-- Check if deletion was successful.
	if (not res) then
		-- Deletion not successful, show error to user and admins.
		message = "*** Error!\nCould not delete file!\n"..
				"Error message was:"..err.."\nSQL statement: "..sql;
		MsgPm(user, "Error! Could not delete file due to SQL error, admins have been notified.");
		MsgOps(set_bot_name, message, 5);
		return false;
	end;

	-- Check if alert all admins.
	if (CheckAlert() == true) then
		-- Alert admins set, send message.
		MsgOps(set_bot_name, "** User \""..user.."\" deleted file with id #"..id, 5);
	end;

	-- Show confirmation message, and return successfully.
	MsgPm(user, "*** File deleted successfully.");
	return 1;
end;

-- Add file to database.
function AddFile(user, data)
	-- Define local variables, for later use.
	local values, sql, res, err, val, found, message;
	local ft, title, filename, path, comment, test;

	-- Requested file-add, sort variables and call function.
	_, _, ft, data = string.find(data, "[%+!]fadd%s(%S+)%s(.*)");
	title, filename, path, comment = ParseData(data);

	-- Check if file-type has been set correctly.
	if (not ft or ft == "") then
		 -- File type not set, show warning.
		 MsgPm(user, "Error! No legal file-type found, or not set. Please try again with valid input.");
		 return false;
	end;

	-- Check if title and file-name has been set
	if (not title or not filename or title == "" or filename == "") then
		MsgPm(user, "Error! Title or filename missing, please provide both as they are required.");
		return false;
	end;

	-- Check if type ID is numerical or string.
	if (tonumber(ft)) then
		-- Numerical, verify type ID from database.
		sql = "SELECT id FROM "..set_db_types.." WHERE id="..ft;
	else
		-- String, get numerical type ID from database.
		sql = "SELECT id FROM "..set_db_types.." WHERE type='"..ft.."'";
	end;

	-- execute SQL, and check if retrieval was successful.
	res, val = SQ(sql);
	if (not res) then
		message = "*** Error!\nCould not retrieve type-ID from database.\n"..
			"Error message was:"..val.."\nSQL statement: "..sql;
		MsgPm(user, "Error! Could not save data due to SQL error, admins have been notified.");
		MsgOps(set_bot_name, message, 5);
		return false;
	end;

	-- Check if file-type exists.
	if (val == 0) then
		MsgPm(user, "Error! File-type ID not valid, please try again with a valid ID, use !list types.");
		return 1;
	end;

	-- Retrieve verified numerical type ID.
	res, test = SF(0);

	if (res and tonumber(test)) then
		ft = test;
	end;

	-- Verify user input.
	filename = StrFix(filename, user, "%\\%/");
	path = StrFix(path, user, "");
	title = StrFix(title, user, "");

	-- Validate database input.
	if (title == 0) then
		return 0;
	elseif (filename == 0) then
		return 0;
	elseif (path ~= "" and path == 0) then
		return 0;
	elseif (comment ~= "") then
		found = false;
		_, _, found = string.find(data, "([;%|%$])");
		if (found) then
			-- Comment data failed check, send error to user.
			message = "Error! Input contains illegal charachers.\nPlease remove all "..
					"occourances of all the following characters, and try again: ; "
			MsgPm(user, message.."$");
			return false;
		end;
	end;

	-- Check if comment is set.
	if (not comment) then
		-- Comment not set, set to empty string to avoid problems.
		comment = "";
	end;

	-- Replace all backslashes with forward slashes.
	if (string.find(filename, "\\", 1, 1)) then
		filename = string.gsub(filename, "\\", "/");
	end;

	-- Clean up path a bit.
	if (string.sub(filename, -1) == "/") then
		filename = string.sub(filename, 1, -2);
	end;

	-- Add the date and time
	NwsDate = os.date()

	-- Insert data into database.
	fields = "(type, title, file, path, comment, adder, date)";
	values = "\""..ft.."\", \""..title.."\", \""..filename.."\", \""..path.."\", \""..comment.."\", \""..user.."\", \""..NwsDate.."\"";
	sql = "INSERT INTO "..set_db_table.." "..fields.." VALUES ("..values..")";
	res, err = SQ(sql);

	-- Check if insertion was successful.
	if (not res) then
		-- Failed, alert user and Admins, then exit.
		-- Deletion not successful, show error to user and admins.
		message = "*** Error!\nCould not save new item data!\n"..
				"Error message was:"..err.."\nSQL statement: "..sql;
		MsgPm(user, "Error! Could not save data due to SQL error, admins have been notified.");
		MsgOps(set_bot_name, message, 5);
		return false;
	end;

	-- Increase type-count by 1.
	sql = "UPDATE "..set_db_types.." SET count = count+1 WHERE id = "..ft;
	res, err = SQ(sql);

	-- Check if increase was successful.
	if (not res) then
		-- Increase not successful, show error to user and admins.
		message = "*** Error!\nCould not increase type-count!\n"..
				"Error message was:"..err.."\nSQL statement: "..sql;
		MsgPm(user, "Error! Could not save data due to SQL error, admins have been notified.");
		MsgOps(set_bot_name, message, 5);
		return false;
	end;

	-- Check if alert all admins.
	if (CheckAlert() == true) then
		-- Alert admins set, send message.
		MsgOps(set_bot_name, "** User \""..user.."\" added file \""..title.."\".", 5);
	end;

	-- Add succeeded. Show message to user, and return successfuly.
	MsgPm(user, "*** Added file successfully.");
	return 1;
end;

-- Parse the "fadd" data, and return the values as an array.
function ParseData(data)
	-- Define local variables, for later use.
	local ret, pos;
	ret = {};

	-- Check if data has been sent.
	if (not data or data == "") then
		-- Data has not been sent correctly, return false.
		return false;
	end;

	for run = 0, 4, 1 do
		-- Check if parametre is quoted.
		if (string.sub(data, 1, 1) == "\"") then
			-- Parametre quoted, run through string to find end of quoted text.
			for run2 = 2, string.len(data), 1 do
				-- Check if end of quoted string is found.
				if (string.sub(data, run2, run2) == "\"" and string.sub(data, run2 + 1, run2 + 1) == " ") then
					-- Is found, set position and break from loop.
					pos = run2;
					break;
				end;

				-- No end-quote found, set pos to string-length.
				pos = run2;
			end;

			-- Grab the text between the quotes.
			ret[run] = string.sub(data, 2, pos - 1);

			-- Remove the parametre from "data".
			_, _, data = string.find(string.sub(data, string.len(ret[run]) + 2),"\"%s+(.*)");
		else
			-- Parametre is not quoted, grab the text until the first space.
			_, _, ret[run] = string.find(data, "(%S+)");

			-- Remove the parametre from "data".
			_, _, data = string.find(string.sub(data, string.len(ret[run]) + 1),"%s(.*)");
		end;

		-- Check length of data, to see if there's more to be parsed.
		if (not data or string.len(data) <= 0) then
			-- No more to check, break loop.
			break;
		end;
	end;

	-- Return the data parsed.
	return ret[0], ret[1], ret[2], ret[3];
end;

-- Verify contents of string passed, "xb" is extra characters to disallow.
function StrFix(data, user, xb)
	-- Declare local variables, for later use.
	local denylist, err, found, message, denytext, temp;

	-- Check if data has been passed.
	if (not data or data == "") then
		 -- No data passed, exit without doing anyhting.
		 return "";
	end;

	-- Set up list over forbidden characters.
--	denylist = "%;%?%*%:%<%>%|%$%\"\n\r\v\t";
--	denytext = " ; ? * : < > $ \" %";
	-- Set up list over forbidden characters modified to allow smiley and links.
	denylist = "%;%*%<%>%|%$\"\n\r\v\t";
	denytext = " ; < > $ * \" ";

	-- Verify content of String.
	_, _, found = string.find(data, "(["..denylist..xb.."])");
	if (found) then
		-- String failed check, send error to user.
		message = "Error! Input contains illegal charachers.\nPlease remove all occourances of "..
				"all whitespaces (except space) plus the following characters, and try again: "
		MsgPm(user, message..denytext..xb);
		return false;
	end;

	-- Format string, to be sql-safe.
	if (string.find(data, "\\", 1, 1)) then
		-- Get length of string.
		len = string.len(data);
		temp = "";

		-- Backslach found, escape it.
		for run = 0, len, 1 do
			-- Get the next char from string.
			char = string.sub(data, run, run);

			-- Check if next char is a slash.
			if (char == "\\") then
				-- Slash found, escape it.
				char = "\\\\";
			end;

			-- Populate string with next char.
			temp = temp..char;
		end;

		-- Restore data-string from temp.
		data = temp;
	end;

	-- Return string
	return data;
end;

-- Check if alert all admins have been activated.
function CheckAlert()
	if (not set_op_alert or set_op_alert == 0) then
		-- Don't alert.
		return false;
	end;

	-- Alert.
	return true;
end;

-- SQL-query short-hand function.
function SQ(sql)
	return VH:SQLQuery(sql);
end;

-- SQL-fetch short-hand function.
function SF(row)
	return VH:SQLFetch(row);
end;

-- Sends private messages to spesified user.
function MsgPm(user, data)
	return VH:SendDataToUser("$To: "..user.." From: "..set_bot_name.." $<"..set_bot_name.."> "..data.."|", user);
end;

-- Sends message to user in main chat.
function MsgUser(user,data)
	return VH:SendDataToUser("<"..set_bot_name.."> "..data.."|", user);
end;

-- Sends PM to all Operators, or higher.
function MsgOps(botname, data, lev_min)
	return VH:SendPMToAll(data, botname, lev_min, 10);
end;

-- Sends messages to main, for users between "lev_min" and "lev_max".
function MsgMain(data, lev_min, lev_max)
	return VH:SendDataToAll("<"..set_bot_name.."> "..data.."|", lev_min, lev_max);
end;

-- Checks if user is of required class or higher.
function IsClass(nick, class_min)
	-- Define local variables, for later use.
	local res, class;

	-- Get class of user "nick".
	res, class = VH:GetUserClass(nick);

	-- Check if retrieval was successful, and class is higher than mininum class required.
	if (res and class >= class_min) then
		-- Has the needed access.
		return true;
	end;

	-- Don't have sufficient access, or failed checking.
	return false;
end;

-- Returns value of config variable "var".
function Get_Config(var)
	-- Define local variables, for later use.
	local res, val;

	-- Get value of config variable "var".
	res, val = VH:GetConfig("config", var);

	-- Check if extraction was successful.
	if (not res) then
		-- Extraction failed, return empty string.
		return "";
	end;

	-- Success, return value.
	return val;
end;

-- Send a menu option to user.
function MenuOpt(user, title, text, cmd)
	return VH:SendDataToUser ("$UserCommand 1 3 "..title.."\\"..text.."$<%[mynick]> "..cmd.."&#124;|", user);
end;

-- Sends a menu divider to the user.
function MenuDiv(user)
	return VH:SendDataToUser ("$UserCommand 0 3|", user);
end;
