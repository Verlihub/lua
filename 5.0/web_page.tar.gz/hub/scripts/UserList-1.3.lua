--|                                                      |--
--| UserList v 1.3                                       |--
--| Written by Hellkeepa, hellkeeper_1@hotmail.com       |--
--| CopyLeft, but please let me know if you change       |--
--| anything. Always remember to credit original author: |--
--| No-one appreciates having their work stolen. ;-)     |--
--|                                                      |--

--[[Changelog:
-- 1.3	Fixed typo in bot's e-mail address variable,
		added deconstructor routines to empty DB, and
		a delimiter in the SQL query for inserting
		initial users.

-- 1.2	Added capturing of bool in VH:GetNickList().

-- 1.1	Minor change to RegExp, for optimalisation and
		preventing a possible bug.

-- 1.0	Added a missing ")", and script is fully working

-- 0.3	Added code for inserting of online users
		on load-time, as well as changed the colons
		in the two events to underscores.

-- 0.2	Added bot, and "Running" message.

-- 0.1	Added logging of users on connection and
		disconnection, as well as variables for
		configuration of table and bot.
--]]--

-- Set this to "false" to use existing bot, "true" to add new bot.
set_bot_new = false;

-- The name for the bot
set_bot_name = "UserList"

-- Replace with your e-mail address.
set_bot_email = "hellkeeper_1 (at) hotmail (dot) com";

-- Change this too, if you want; Bot-description.
set_bot_desc = "Mantains userlist for online display.";

-- Name for table. Can be changed, but no need.
set_db_table = "users_list";

--|                                                      |--
--| Please do not edit anything below, unless you        |--
--| _know_ what you're doing: Very good chance of        |--
--| rendering the script unusable otherwise.             |--
--|                                                      |--


-- Main function, called when loading script.
function Main()
	-- Define local variables, for later use.
	local res, err, sql, message, users;
	local dlim = "";

	-- Check if new bot should be added.
	if (set_bot_new and set_bot_new ~= 0) then
		-- Add bot.
		VH:AddRobot(set_bot_name, 10, set_bot_desc, "Bot ", set_bot_email, "0");
	else
		-- Get name of HUB security bot.
		set_bot_name = VH:GetConfig("config","hub_security");
	end;

	-- Define table, if it doesn't exist.
	sql = "CREATE TABLE IF NOT EXISTs "..set_db_table.." (nick VARCHAR(30) NOT NULL, PRIMARY KEY(nick))";
	res, err = SQ(sql);

	-- Check if creation was successful.
	if (not res) then
		-- Failed, show error to admins.
		message = "*** Error!\n Could not create table!\n"..
				"Error message was:"..err.."\nSQL statement: "..sql;
		MsgOps(set_bot_name, message, 5);
		return 0;
	end;

	-- Delete all previous data in the database.
	sql = "DELETE FROM "..set_db_table;
	res, err = SQ(sql);

	-- Check if deletion succeeded.
	if (not res) then
		-- Failed, show error to admins.
		message = "*** Error!\n Could not delete old users!\n"..
				"Error message was:"..err.."\nSQL statement: "..sql;
		MsgOps(set_bot_name, message, 5);
		return 0;
	end;

	-- Get list over active users.
	_, users = VH:GetNickList();
	_, _, users = string.find(users, "%$[Nn]ick[Ll]ist%s(.*)");

	-- Spool through users and build SQL statement.
	sql = "INSERT INTO "..set_db_table.." VALUES";
	for nick in string.gfind(users, "([^%$%|]+)%$%$") do
		sql = sql..dlim.." ('"..nick.."')";
		dlim = ",";
	end;

	-- Insert active users into table.
	res, err = SQ(sql);

	-- Check if successful.
	if (not res) then
		-- Failed, show error to admins.
		message = "*** Error!\n Could not insert active users!\n"..
				"Error message was:"..err.."\nSQL statement: "..sql;
		MsgOps(set_bot_name, message, 5);
		return 0;
	end;

	-- Return successfully.
-- 	MsgMain("\n*** UserList is up and running!", 10, 10);
	return 1;
end;

-- Called upon user joining HUB.
function VH_OnUserLogin(nick)
	-- Define local variables, for later use.
	local res, err, sql, message;

	-- Insert nick into table.
	sql = "INSERT INTO "..set_db_table.." VALUES ('"..nick.."')";
	res, err = SQ(sql);

	-- Check if insertion was successful.
	if (not res) then
		-- Failed, show error to admins.
		message = "*** Error!\n Could not save nick!\n"..
		"Error message was:"..err.."\nSQL statement: "..sql;
		MsgOps(set_bot_name, message, 5);
		return 0;
	end;

	-- Return successfully.
	return 1;
end;

-- Called upon user leaving HUB.
function VH_OnUserLogout(nick)
	-- Define local variables, for later use.
	local res, err, sql, message;

	-- Delete nick from table.
	sql = "DELETE FROM "..set_db_table.." WHERE nick='"..nick.."'";
	res, err = SQ(sql);

	-- Check if deletion was successful.
	if (not res) then
		-- Failed, show error to admins.
		message = "*** Error!\n Could not delete nick!\n"..
		"Error message was:"..err.."\nSQL statement: "..sql;
		MsgOps(set_bot_name, message, 5);
		return 0;
	end;

	-- Return successfully.
	return 1;
end;

-- SQL-query short-hand function.
function SQ(sql)
	return VH:SQLQuery(sql);
end;

-- Sends PM to all Operators, or higher.
function MsgOps(botname, data, lev_min)
	return VH:SendPMToAll(data, botname, lev_min, 10);
end;